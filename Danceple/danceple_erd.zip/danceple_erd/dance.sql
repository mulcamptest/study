create user danceple
identified by danceple;

grant connect, resource
to danceple;


/* Drop Tables */

DROP TABLE apply CASCADE CONSTRAINTS;
DROP TABLE teacher CASCADE CONSTRAINTS;
DROP TABLE genre CASCADE CONSTRAINTS;
DROP TABLE member CASCADE CONSTRAINTS;
DROP TABLE grade CASCADE CONSTRAINTS;
DROP TABLE team CASCADE CONSTRAINTS;




/* Create Tables */

CREATE TABLE apply
(
	memberid varchar2(20) NOT NULL,
	teamid number NOT NULL,
	genre1 number NOT NULL,
	genre2 number,
	genre3 number,
	PRIMARY KEY (memberid, teamid)
);


CREATE TABLE genre
(
	genreid number NOT NULL,
	gname varchar2(50) NOT NULL,
	PRIMARY KEY (genreid)
);


CREATE TABLE grade
(
	gradeid number NOT NULL,
	gardename varchar2(11) NOT NULL,
	PRIMARY KEY (gradeid)
);


CREATE TABLE member
(
	memberid varchar2(20) NOT NULL,
	memberpwd varchar2(20) NOT NULL,
	membername varchar2(30) NOT NULL,
	phone varchar2(12) NOT NULL,
	birthday date NOT NULL,
	email varchar2(50) NOT NULL,
	gender varchar2(5) NOT NULL,
	gradeid number NOT NULL,
	PRIMARY KEY (memberid)
);


CREATE TABLE teacher
(
	tname varchar2(50) NOT NULL,
	genreid number NOT NULL,
	teamid number NOT NULL,
	PRIMARY KEY (genreid, teamid)
);


CREATE TABLE team
(
	teamid number NOT NULL,
	teamname varchar2(50) NOT NULL,
	PRIMARY KEY (teamid)
);



/* Create Foreign Keys */

ALTER TABLE apply
	ADD FOREIGN KEY (genre1)
	REFERENCES genre (genreid)
;


ALTER TABLE apply
	ADD FOREIGN KEY (genre2)
	REFERENCES genre (genreid)
;


ALTER TABLE apply
	ADD FOREIGN KEY (genre3)
	REFERENCES genre (genreid)
;


ALTER TABLE teacher
	ADD FOREIGN KEY (genreid)
	REFERENCES genre (genreid)
;


ALTER TABLE member
	ADD FOREIGN KEY (gradeid)
	REFERENCES grade (gradeid)
;


ALTER TABLE apply
	ADD FOREIGN KEY (memberid)
	REFERENCES member (memberid)
;


ALTER TABLE apply
	ADD FOREIGN KEY (teamid)
	REFERENCES team (teamid)
;


ALTER TABLE teacher
	ADD FOREIGN KEY (teamid)
	REFERENCES team (teamid)
;



